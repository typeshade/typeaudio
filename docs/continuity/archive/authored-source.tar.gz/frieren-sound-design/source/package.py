from pathlib import Path
import json,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
for p in sorted((root/'stems').glob('*.wav')):
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(p),str(p.with_suffix('.flac'))],check=True)
files=[root/'README.md',root/'cue-sheet.csv']
files+=list((root/'source').glob('*'))+list((root/'projects').glob('*.json'))+list((root/'stems').glob('*.flac'))
files+=[root/'analysis/render-report.json',root/'analysis/mix-report.json']
with zipfile.ZipFile(root/'typeaudio-design-session.zip','w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for p in files: z.write(p,p.relative_to(root))
print('Packaged',len(files),'files', (root/'typeaudio-design-session.zip').stat().st_size,'bytes')
