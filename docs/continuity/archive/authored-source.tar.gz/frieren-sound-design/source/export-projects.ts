import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {DEFAULT} from '/workspace/web/apps/typeaudio/website/sound/defaultPatch.ts';
import {validateScene} from '/workspace/web/apps/typeaudio/website/video-model.ts';
import {packAudio,unpackAudioAssets} from '/workspace/web/apps/typeaudio/website/audio-asset.ts';
const s=JSON.parse(readFileSync('source/session.json','utf8'));
let part=0;const index:any[]=[];
async function project(start:number,end:number){
 const entries=s.cues.filter((c:any)=>c.time<end&&c.time+c.duration>start);
 if(entries.length>24){let mid=(start+end)/2;await project(start,mid);await project(mid,end);return;}
 const assets=entries.map((c:any)=>{const b=readFileSync(`cues/${c.id}.f32`);return {id:createHash('sha256').update(b).digest('hex'),name:`${c.id} ${c.name}`,frames:b.length/4,pcm:new Float32Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength))};});
 const scene=validateScene({version:1,name:`Frieren design ${++part}`,media:{kind:'file',name:'reference.mp4'},start,end,loop:false,original:0,effects:.7,cues:entries.map((c:any,i:number)=>({id:c.id,name:c.name,time:c.time,gain:c.gain,muted:false,audio:{id:assets[i].id,name:assets[i].name,frames:assets[i].frames},patch:{...DEFAULT,graph:c.graph,volume:.65,duration:Math.max(.5,Math.min(4,c.duration)),release:.02,voices:1}}))});
 const audioAssets=assets.map(packAudio);
 await unpackAudioAssets(audioAssets,scene.cues.map(c=>c.audio!));
 const file=`part-${String(part).padStart(2,'0')}.json`;
 writeFileSync(`projects/${file}`,JSON.stringify({...scene,audioAssets}));
 index.push({file,start,end,cues:entries.length});
}
for(let start=0;start<s.duration;start+=30)await project(start,Math.min(start+30,s.duration));
writeFileSync('projects/index.json',JSON.stringify(index,null,2));console.log('Validated',index.length,'portable editor projects, including PCM checksums');
