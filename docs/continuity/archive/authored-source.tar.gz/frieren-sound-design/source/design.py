import json, pathlib
root=pathlib.Path(__file__).resolve().parents[1]
programs={
'room': 'state0 = state0 + 0.006 * (input - state0);\nstate1 = state1 + 0.035 * (input - state1);\nout = state0 * 1.7 + state1 * 0.12 + sin(time * 6.2831853 * 39) * 0.018;',
'rumble': 'state0 = state0 + 0.012 * (input - state0);\nconst env: f32 = min(1, time / 0.018) * exp(-time / p1);\nstate1 = fract(state1 + (p0 + 45 * exp(-time * 5)) / sampleRate);\nout = (state0 * 2 + sin(state1 * 6.2831853) * 0.45) * env;',
'fire': 'const env: f32 = min(1, time / 0.035) * exp(-time / p1);\nstate0 = state0 + 0.09 * (input - state0);\nstate1 = fract(state1 + (p0 + 110 * exp(-time * 3)) / sampleRate);\nconst flame: f32 = sin(state1 * 6.2831853 + sin(time * 71) * 2.2);\nout = tanh((state0 * 2.3 + flame * 0.35) * 1.5) * env * (0.85 + 0.15 * sin(time * 163));',
'whoosh': 'const x: f32 = clamp(time / p1, 0, 1);\nconst env: f32 = sin(x * 3.14159265);\nstate0 = state0 + (0.02 + x * 0.3) * (input - state0);\nstate1 = fract(state1 + (p0 * (1 - x) + 80) / sampleRate);\nout = (state0 * 1.8 + sin(state1 * 6.2831853) * 0.08) * env;',
'arc': 'const env: f32 = min(1, time / 0.003) * exp(-time / p1);\nstate0 = state0 + 0.18 * (input - state0);\nstate1 = fract(state1 + (p0 + sin(time * 91) * 180) / sampleRate);\nconst buzz: f32 = sin(state1 * 6.2831853 + sin(time * 6.2831853 * 1331) * 2.5);\nconst pulse: f32 = 0.35 + 0.65 * abs(sin(time * 6.2831853 * 29));\nout = (buzz * 0.33 + (input - state0) * 0.48) * pulse * env;',
'shield': 'const env: f32 = min(1, time / 0.003) * exp(-time / p1);\nstate0 = state0 + 0.16 * (input - state0);\nconst ring: f32 = sin(time * 6.2831853 * p0) + 0.45 * sin(time * 6.2831853 * p0 * 1.4142) + 0.2 * sin(time * 6.2831853 * p0 * 2.718);\nout = ring * 0.26 * env + (input - state0) * exp(-time * 42) * 0.3;',
'beam': 'const env: f32 = min(1, time / 0.012) * exp(-time / p1);\nstate0 = state0 + 0.13 * (input - state0);\nstate1 = fract(state1 + (p0 + 900 * exp(-time * 12)) / sampleRate);\nout = (sin(state1 * 6.2831853 + sin(time * 6.2831853 * 71) * 0.7) * 0.32 + state0 * 1.3) * env;',
'stone': 'const env: f32 = min(1, time / 0.002) * exp(-time / p1);\nstate0 = state0 + 0.07 * (input - state0);\nout = (state0 * 2.1 + sin(time * 6.2831853 * p0) * 0.42 * exp(-time * 17) + input * 0.25 * exp(-time * 34)) * env;',
'spark': 'const env: f32 = min(1, time / 0.002) * exp(-time / p1);\nout = (sin(time * 6.2831853 * p0 + sin(time * 6.2831853 * p0 * 1.7) * 0.8) * 0.4 + input * exp(-time * 65) * 0.2) * env;',
'magic': 'const env: f32 = min(1, time / 0.25) * exp(-time / p1);\nconst shimmer: f32 = sin(time * 6.2831853 * p0 + sin(time * 6.2831853 * 3.1) * 1.2);\nout = (shimmer * 0.2 + sin(time * 6.2831853 * p0 * 1.501) * 0.13 + sin(time * 6.2831853 * p0 * 2.003) * 0.08) * env;',
'cloth': 'state0 = state0 + 0.12 * (input - state0);\nstate1 = state1 + 0.016 * (input - state1);\nout = (state0 - state1) * min(1, time / 0.015) * exp(-time / p1);',
'pressure': 'const env: f32 = min(1, time / 0.002) * exp(-time / p1);\nstate0 = fract(state0 + (p0 + 95 * exp(-time * 14)) / sampleRate);\nstate1 = state1 + 0.025 * (input - state1);\nout = (sin(state0 * 6.2831853) * 0.72 + state1 * 0.8) * env;'
}
(root/'source'/'programs.json').write_text(json.dumps(programs,indent=2))
cues=[]
def cue(t,f,d,g,name,p=300,decay=None,pan=0):
 cues.append(dict(id=f'cue-{len(cues)+1:03}',time=t,family=f,duration=d,gain=g,name=name,frequency=p,decay=decay or max(.04,d/3),pan=pan,seed=1+(202600+len(cues)*137)%65535,wet=.22 if f not in ('room','cloth') else .08))
for t in range(0,188,20): cue(t,'room',min(20,188-t),.12,'Ruined hall air',60,10)
for t,d,g in [(0,3,.7),(10,4,.5),(27,4,.7),(34,6,.7),(40.6,4,.65),(55.5,4,.7),(64,4,.5),(84.5,4,.7),(95.5,5,.8),(108,3,.55),(128,5,.7),(145.4,4,.8),(178.6,5,.75)]: cue(t,'rumble',d,g,'Stone chamber pressure',38,.8)
for t,d,p,g in [(3.1,7,120,.5),(10.5,3.8,160,.62),(17.2,5.4,95,.65)]: cue(t,'fire',d,g,'Red heat / molten orbit',p,d/2,pan=-.25)
for t,d,g in [(7.0,1,.4),(13,.6,.42),(15.8,1.2,.3),(21.4,.9,.55),(30.1,.65,.18),(31.1,.5,.16),(39.8,1.4,.5),(59.5,.7,.12),(71.2,.5,.2),(89.4,.55,.15),(110.1,.65,.2),(123.7,.7,.4),(144.4,.65,.4),(151,.8,.16),(175.8,.65,.45)]: cue(t,'whoosh',d,g,'Air displacement / movement',650,d,pan=.25)
for t,p,g in [(8,670,.35),(14.5,740,.3),(26.2,930,.6),(31.6,820,.28),(45.4,570,.6),(61.1,750,.45),(65,660,.35),(87.1,900,.5),(101.3,1050,.42),(105.7,780,.5),(111.0,950,.36),(114.2,700,.3)]: cue(t,'shield',2,g,'Hexagonal ward contact',p,.48,pan=.15)
cue(23.3,'magic',2.4,.48,'Red spell condensation',196,1.2)
cue(25.55,'pressure',1,.65,'Red spell rupture',54,.19)
for t,d,g in [(43.1,3,.44),(46.6,3.3,.55),(49.5,3.8,.65),(53.3,2.3,.6)]: cue(t,'arc',d,g,'Violet electrical tendrils',840,d/2,pan=-.3)
cue(56.0,'pressure',2.6,.8,'Electrical field collapse',43,.65)
for t,d,g,p in [(61.3,1.6,.4,490),(71.45,1.4,.45,550),(86.4,2.1,.6,620),(93.0,7,.48,440),(100.1,3,.55,510),(104.4,4.2,.62,680),(112.0,2.1,.4,740),(118.8,1.4,.45,580),(124.8,2.3,.65,610),(126.3,3.4,.7,710),(128.0,3.0,.72,630),(176.4,2.7,.7,510)]: cue(t,'beam',d,g,'Blue-white spell / beam',p,d/2,pan=.2)
for t,d,p,g in [(82.6,2.4,260,.4),(90.6,3,330,.38),(98.5,4,440,.38),(119.4,5.2,350,.38),(140.9,3,160,.12),(160.2,7,220,.23),(174.0,3.1,370,.38)]: cue(t,'magic',d,g,'Runic energy resonance',p,d/2,pan=-.15)
cue(145.15,'pressure',1.4,.85,'Unseen force / chest impact',32,.28)
cue(146,'cloth',.8,.3,'Clothing struck / body recoil',300,.2)
for t in [11.5,26.8,34.1,40.9,56.3,64.9,85.7,96.1,106,128.5,145.8,179.3]:
 for j in range(3): cue(t+j*.23,'stone',.65,.24/(1+j*.4),'Falling masonry / fragment',100+j*127,.12,pan=(-.6+j*.6))
for t in [26.5,58.0,72.0,86.9,101.5,106.4,111.4,125.6,130.2,178.4]:
 for j in range(2): cue(t+j*.19,'spark',.8,.13,'Magic fragments',1700+j*673,.22,pan=-.4+j*.8)
for t in [152.5,157.0,166.9,170.8,184.0]: cue(t,'cloth',.65,.16,'Quiet fabric movement',200,.13)
cue(179.1,'pressure',2.6,.8,'Final blue discharge',46,.55)
cue(183.8,'stone',1.5,.3,'Landing and settling stone',110,.24)
cue(188.3,'whoosh',1.2,.2,'End-card transition',700,1.2)
for t,p in [(194,220),(198,330),(202,294),(206,196)]: cue(t,'magic',3.8,.18,'End-card tonal signature',p,1.4,pan=.2)
cue(209.0,'whoosh',2.2,.2,'End-card fade',320,2.2)
cues.sort(key=lambda c:c['time'])
(root/'source'/'session.json').write_text(json.dumps({'version':1,'duration':212.578685,'sampleRate':48000,'reference':'reference.mp4','cues':cues},indent=2))
print('Designed',len(cues),'cues /',len(programs),'synthesis families')
