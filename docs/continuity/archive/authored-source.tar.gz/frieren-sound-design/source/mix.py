import json,pathlib,numpy as np,wave,hashlib,csv,subprocess
from scipy.signal import fftconvolve
root=pathlib.Path(__file__).resolve().parents[1]; rate=48000
s=json.load(open(root/'source/session.json')); N=round(s['duration']*rate)
stems={}; rng=np.random.default_rng(8262026)
# Deterministic diffuse hall: frequency-damped tail plus distinct early reflections.
t=np.arange(round(.95*rate))/rate
ir=rng.normal(0,1,len(t))*np.exp(-t/0.18);ir=np.convolve(ir,[.2,.6,.2],mode='same');ir/=np.sqrt(np.sum(ir*ir));ir*=.45
for at,g in [(.041,.25),(.079,.18),(.137,.11)]: ir[round(at*rate)]+=g
mapping={'room':'ambience','rumble':'weight','pressure':'weight','fire':'red-magic','arc':'violet-magic','beam':'blue-magic','magic':'tonal-magic','shield':'shields','stone':'debris','spark':'debris','cloth':'movement','whoosh':'movement'}
def wav(path,data):
 with wave.open(str(path),'wb') as f:
  f.setnchannels(1 if data.ndim==1 else data.shape[1]);f.setsampwidth(2);f.setframerate(rate);f.writeframes((np.clip(data,-1,1)*32767).astype('<i2').tobytes())
for c in s['cues']:
 assert 0<=c['gain']<=1
 a=np.fromfile(root/'cues'/f"{c['id']}.f32",dtype='<f4')
 wav(root/'cues'/f"{c['id']}.wav",a)
 wet=fftconvolve(a,ir).astype('f4')*c['wet']
 L=len(wet);dry=np.pad(a,(0,L-len(a))); pan=c['pan']
 stereo=np.stack([dry*np.sqrt((1-pan)/2),dry*np.sqrt((1+pan)/2)],axis=1)
 stereo[:,0]+=wet*.65;stereo[:,1]+=np.roll(wet,round(.011*rate))*.65
 # Automated density reduction around dialogue / the silent-force reveal.
 at=c['time'];ducks=1
 if 67<=at<82 or 135<=at<145 or 149<=at<174 or 181<=at<188: ducks=.65
 group=mapping[c['family']];stem=stems.setdefault(group,np.zeros((N,2),dtype='f4'))
 i=round(at*rate);length=min(L,N-i)
 stem[i:i+length]+=stereo[:length]*c['gain']*ducks
raw=sum(stems.values());peak=float(np.max(abs(raw)));scale=.84/max(peak,1e-9)
# Smooth master fade at beginning and final end-card; no clip-by-clip peak normalization.
fade=np.ones(N,dtype='f4');fade[:2400]=np.linspace(0,1,2400);fade[-96000:]=np.linspace(1,0,96000)
mix=raw*scale*fade[:,None]
wav(root/'redesign-mix.wav',mix)
for k,data in stems.items(): wav(root/'stems'/f'{k}.wav',data*scale*fade[:,None])
report={'durationSeconds':len(mix)/rate,'cues':len(s['cues']),'stems':len(stems),'rawPeak':peak,'masterGain':scale,'peakDbFS':float(20*np.log10(max(abs(mix).max(),1e-12))),'rmsDbFS':float(20*np.log10(np.sqrt(np.mean(mix**2)))),'nonFiniteSamples':int((~np.isfinite(mix)).sum()),'clippedSamples':int((abs(mix)>=1).sum()),'sha256Pcm':hashlib.sha256(mix.astype('<f4').tobytes()).hexdigest()}
json.dump(report,open(root/'analysis/mix-report.json','w'),indent=2)
with open(root/'cue-sheet.csv','w') as f:
 w=csv.writer(f);w.writerow(['id','start_seconds','duration','family','description','gain','pan','seed']);w.writerows([[c[k] for k in ['id','time','duration','family','name','gain','pan','seed']] for c in s['cues']])
print(json.dumps(report))
