"""Make a mobile listening derivative; retain the dynamics master and normalization receipts."""
import json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
def run(args,log=None):
 with (ROOT/'analysis'/log).open('w') if log else open('/dev/null','w') as f:
  subprocess.run(['ffmpeg','-hide_banner','-y',*args],stderr=f,check=True,cwd=ROOT)
run(['-i','redesign-v2.wav','-af','loudnorm=I=-18:TP=-2:LRA=11:print_format=json','-f','null','-'],'mobile-pass1.log')
s=(ROOT/'analysis/mobile-pass1.log').read_text();d=json.JSONDecoder().raw_decode(s[s.rfind('{'):])[0]
f=f"loudnorm=I=-18:TP=-2:LRA=11:measured_I={d['input_i']}:measured_TP={d['input_tp']}:measured_LRA={d['input_lra']}:measured_thresh={d['input_thresh']}:offset={d['target_offset']}:linear=false:print_format=json"
run(['-i','redesign-v2.wav','-af',f,'-ar','48000','-c:a','pcm_s24le','redesign-v2-mobile.wav'],'mobile-pass2.log')
for src,name in [('redesign-v2.wav','redesign-v2'),('redesign-v2-mobile.wav','redesign-v2-mobile')]:
 run(['-i',src,'-c:a','aac','-b:a','192k','-movflags','+faststart',name+'.m4a'])
run(['-i','redesign-v2-mobile.m4a','-af','ebur128=peak=true','-f','null','-'],'mobile-loudness.log')
print((ROOT/'analysis/mobile-loudness.log').read_text().split('Summary:')[-1])
