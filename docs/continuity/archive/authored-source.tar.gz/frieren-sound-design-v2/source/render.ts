import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { compileGraph } from '/workspace/typeaudio-feedback/src/graph/compiler/index.ts';
import { GraphDsp } from '/workspace/typeaudio-feedback/src/graph/runtime.ts';
for(const dir of ['cues','source','analysis','projects','stems'])mkdirSync(dir,{recursive:true});
const session=JSON.parse(readFileSync('source/session.json','utf8'));
const programs=JSON.parse(readFileSync('source/programs.json','utf8'));
const reports:any[]=[];
const installed=new Set<string>();
const chosen = process.env.EVENT_ONLY;
for(const c of session.cues.filter((c:any)=>!chosen || c.eventId===chosen)){ 
 const node=(id:string,kind:string,inputs:any,values:number[],code='')=>({id,kind,name:id,x:id==='noise'?0:id==='design'?250:500,y:0,inputs,values,code,bypass:false});
 c.graph={version:1,parameters:[{name:'Frequency',min:20,max:8000,value:c.frequency},{name:'Decay',min:.001,max:30,value:c.decay},{name:'Duration',min:.01,max:30,value:c.duration},{name:'Variation',min:0,max:1,value:.5}],nodes:[node('noise','noise',{},[c.seed]),node('design','code',{input:'noise'},[],programs[c.family]),node('output','output',{input:'design'},[])]};
 const p=compileGraph(c.graph);
 if(!installed.has(p.key)){new Function(p.code)();installed.add(p.key);writeFileSync(`source/${c.family}.shade.ts`,p.source);}
 const dsp=new GraphDsp({graph:c.graph,volume:.7});
 const total=Math.round(c.duration*48000),pcm=new Float32Array(total),block=new Float32Array(128);
 let peak=0,energy=0,clipped=0;const begin=performance.now();
 for(let at=0;at<total;at+=128){const n=Math.min(128,total-at);dsp.process(block,n);for(let i=0;i<n;i++){const fade=Math.min(1,(total-at-i)/1440);const v=block[i]!*fade;pcm[at+i]=v;peak=Math.max(peak,Math.abs(v));energy+=v*v;if(Math.abs(v)>=.99999)clipped++;}}
 if(dsp.invalidSamples||!energy)throw Error(`${c.id}: invalid or silent DSP`);
 writeFileSync(`cues/${c.id}.f32`,new Uint8Array(pcm.buffer));
 reports.push({id:c.id,family:c.family,peak,rms:Math.sqrt(energy/total),invalid:dsp.invalidSamples,clipped,computeMs:performance.now()-begin});
}
writeFileSync('source/session.json',JSON.stringify(session,null,2));
writeFileSync('analysis/render-report.json',JSON.stringify({engine:execFileSync('git',['-C','/workspace/typeaudio-feedback','rev-parse','HEAD'],{encoding:'utf8'}).trim(),compiler:'87af4eb0d9d15f02b66b8341b72cab0944290472',families:installed.size,cues:reports},null,2));
console.log(JSON.stringify({cues:reports.length,families:installed.size,invalid:reports.reduce((n,r)=>n+r.invalid,0)}));
