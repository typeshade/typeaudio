"""Stereo host mixer: time-varying pan, independent causal room tails, narrative automation.
TypeAudio produces all dry sources. This host handles mix operations not yet in the editor.
"""
import json, pathlib, hashlib, csv, wave
import numpy as np
from scipy.signal import fftconvolve, butter, sosfilt
ROOT=pathlib.Path(__file__).resolve().parents[1];SR=48000
session=json.loads((ROOT/'source/session.json').read_text());N=round(session['duration']*SR)
GROUP={'air':'ambience','heat':'red-magic','flight':'movement','charge':'preparation','crack':'attacks','weight':'weight','electric':'violet-magic','beam':'blue-magic','ward':'shields','stone':'masonry','dust':'masonry','cloth':'movement','shard':'shields','rune':'resonance'}
def write_wav(path,a):
 with wave.open(str(path),'wb') as f:
  f.setnchannels(a.shape[1] if a.ndim==2 else 1);f.setsampwidth(3);f.setframerate(SR);f.writeframes((np.clip(a,-1,1)*8388607).astype('<i4').view('u1').reshape(-1,4)[:,:3].tobytes())
def automation(name,t):
 points=np.array(session['automation'][name]);return np.interp(t,points[:,0],points[:,1])
def room(seed):
 rng=np.random.default_rng(seed);t=np.arange(round(1.4*SR))/SR
 a=rng.normal(size=len(t))*np.exp(-t/.27)
 a=sosfilt(butter(2,3800,fs=SR,output='sos'),a)
 a[:round(.031*SR)]=0;a/=max(1e-9,np.sqrt((a*a).sum()));a*=.38
 for delay,gain in [(.037,.28),(.071,.19),(.113,.12),(.173,.075)]:a[round(delay*SR)]+=gain
 return a.astype('f4')
irs=[room(601),room(941)];stems={}
for c in session['cues']:
 a=np.fromfile(ROOT/'cues'/f"{c['id']}.f32",dtype='<f4')
 a=sosfilt(butter(2,28,'highpass',fs=SR,output='sos'),a).astype('f4')
 if c['family'] in ('electric','crack','shard'): a=sosfilt(butter(2,7500,fs=SR,output='sos'),a).astype('f4')
 x=np.arange(len(a))/SR+c['time'];control=automation('space' if c['family']=='air' else 'dialogue',x)
 if c['family'] in ('weight','crack') and c['eventId'] in ('event-42','event-48'): control=np.ones(len(a))
 a*=control.astype('f4')*c['gain']
 pan=np.linspace(c['pan'],c['panEnd'],len(a));dry=np.stack((a*np.sqrt((1-pan)/2),a*np.sqrt((1+pan)/2)),axis=1)
 wet=np.stack([fftconvolve(a,ir) for ir in irs],axis=1).astype('f4')*c['wet']
 stereo=wet;stereo[:len(a)]+=dry
 start=round(c['time']*SR);length=min(len(stereo),N-start)
 group=GROUP[c['family']];stem=stems.setdefault(group,np.zeros((N,2),dtype='f4'))
 stem[start:start+length]+=stereo[:length]
raw=sum(stems.values());peak=float(abs(raw).max());gain=min(3.0,.84/max(peak,1e-9))
fade=np.ones(N,dtype='f4');fade[:2400]=np.linspace(0,1,2400);fade[-48000:]=np.linspace(1,0,48000)
master=raw*gain*fade[:,None]
write_wav(ROOT/'redesign-v2.wav',master)
for name,data in stems.items():write_wav(ROOT/'stems'/f'{name}.wav',data*gain*fade[:,None])
def rms(a):return float(20*np.log10(max(1e-12,np.sqrt(np.mean(a.astype('f8')**2)))))
report=dict(durationSeconds=N/SR,events=len(session['events']),layers=len(session['cues']),stemCount=len(stems),masterGain=gain,peakDbFS=float(20*np.log10(abs(master).max())),rmsDbFS=rms(master),nonFiniteSamples=int((~np.isfinite(master)).sum()),clippedSamples=int((abs(master)>=1).sum()),preForceRmsDbFS=rms(master[round(144.7*SR):round(145.1*SR)]),forceRmsDbFS=rms(master[round(145.19*SR):round(145.49*SR)]),monoRmsDbFS=rms(master.mean(axis=1)),sha256=hashlib.sha256(master.tobytes()).hexdigest(),reviewStatus='Visual spotting and signal checks only; listening review pending')
(ROOT/'analysis/mix-report.json').write_text(json.dumps(report,indent=2))
with (ROOT/'cue-sheet.csv').open('w') as f:
 w=csv.writer(f);keys=['id','eventId','time','duration','family','role','name','gain','pan','panEnd','seed'];w.writerow(keys);w.writerows([[c[k] for k in keys] for c in session['cues']])
print(json.dumps(report))
