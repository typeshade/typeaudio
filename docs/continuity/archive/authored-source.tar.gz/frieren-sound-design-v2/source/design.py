import json, pathlib, random
from programs import PROGRAMS
from spotting import EVENTS
ROOT=pathlib.Path(__file__).resolve().parents[1]
FPS=24000/1001
cues=[]; events=[]
def layer(e,family,offset,duration,gain,pitch=200,decay=.2,wet=.16,role='body',pan=None):
 start=round((e['start']+offset)*48000)/48000
 if start<0: return
 duration=min(duration,188-start)
 if duration<=0: return
 cue_id=f"{e['id']}-{len(cues):03}"
 cues.append(dict(id=cue_id,eventId=e['id'],name=f"{e['label']} / {role}",time=start,duration=duration,family=family,gain=gain*e['intensity'],frequency=pitch,decay=decay,seed=1729+len(cues)*109,pan=e['pan'][0] if pan is None else pan,panEnd=e['pan'][1] if pan is None else pan,wet=wet,role=role))
for i,(start,end,kind,label,p0,p1,intensity,confidence) in enumerate(EVENTS):
 e=dict(id=f'event-{i+1:02}',start=round(start*FPS)/FPS,end=end,kind=kind,label=label,pan=[p0,p1],intensity=intensity,timingConfidence=confidence,timingResolutionSeconds=1/FPS if confidence=='frame' else .25 if confidence=='high' else 2)
 events.append(e);d=end-e['start'];rnd=random.Random(62026+i)
 if kind=='red':
  layer(e,'heat',0,d,.63,92,role='turbulent core',wet=.08)
  layer(e,'flight',0,d,.46,280,role='air path',wet=.1)
 elif kind=='charge':layer(e,'charge',0,d,.56,180 if start<40 else 420,role='rising preparation',wet=.08)
 elif kind=='beam':
  layer(e,'crack',0,.16,.48,550,.035,role='launch transient',wet=.08)
  layer(e,'beam',.015,max(.1,d-.015),.63,260+50*(i%3),role='sustained energy',wet=.1)
  if d>1:layer(e,'weight',.025,min(d,1.8),.35,55,.4,role='low body',wet=.06)
 elif kind=='electric':
  layer(e,'electric',0,d,.5,650,role='unstable arc',wet=.1)
  for j in range(max(2,round(d*2))):
   at=rnd.uniform(.02,max(.03,d-.12))
   layer(e,'crack',at,.12,.18,1300,.022,role='arc snap',pan=rnd.uniform(-.5,.5),wet=.08)
  if start<48:layer(e,'ward',.22,1.2,.45,720,.3,role='barrier contact')
 elif kind in ('blast','force'):
  layer(e,'crack',0,.22,.78,220,.055,role='attack edge',wet=.06)
  layer(e,'weight',.008,1.6,.9,46 if kind=='force' else 53,.28,role='pressure and harmonics',wet=.03)
  if kind!='force':layer(e,'dust',.1,2.8,.6,100,.6,role='expanding air',wet=.25)
 elif kind=='ward':
  layer(e,'ward',0,min(d,2),.55,610+i%4*91,.38,role='inharmonic contact')
  for j in range(3):layer(e,'shard',.12+j*.21,1.1,.16,1300+j*417,.25,role='crystal decay',pan=(-.35+j*.35),wet=.25)
 elif kind in ('collapse','scrape'):
  layer(e,'stone',0,min(d,1.5),.75,93,.22,role='structural crack',wet=.2)
  if kind=='collapse':layer(e,'weight',.035,1.7,.45,58,.4,role='masonry mass',wet=.12)
  layer(e,'dust',.15,min(3,d),.48,100,max(.25,d/3),role='dust tail',wet=.25)
  for j in range(5):
   at=.12+rnd.random()*max(.15,d-.35)
   layer(e,'stone',at,.45,rnd.uniform(.11,.28),rnd.uniform(130,610),rnd.uniform(.025,.09),role='individual debris',pan=rnd.uniform(-.6,.6),wet=.14)
 elif kind=='flight':layer(e,'flight',0,d,.7,650,role='pass-by',wet=.06)
 elif kind=='cloth':layer(e,'cloth',0,d,.32,200,role='fabric',wet=.06)
 elif kind=='rune':layer(e,'rune',0,d,.45,196 if start<110 else 246,role='stable resonance',wet=.28)
 elif kind=='dust':layer(e,'dust',0,d,.5,100,max(.3,d/3),role='settling tail',wet=.3)
# Continuous overlapping room beds; no fresh random restart on each edit scene.
for j,start in enumerate(range(0,188,22)):
 e=dict(id=f'air-{j}',start=start,label='Stone chamber air',pan=[0,0],intensity=1)
 layer(e,'air',0,min(23,188-start),.16,role='ambience',wet=0)
cues.sort(key=lambda c:c['time'])
session=dict(version=2,duration=188,referenceDuration=212.578685,sampleRate=48000,frameRate=FPS,youtubeId='YHCqcyX9N3s',youtubeUrl='https://www.youtube.com/watch?v=YHCqcyX9N3s',mediaOffsetSeconds=0,offsetVerification='Unverified against live YouTube; local supplied reference starts at timeline zero.',events=events,cues=cues,excludedRange=[188,212.578685],excludedReason='Uploader end card, outside the scene.',automation={'space':[[0,1],[134,1],[142.8,.5],[144.7,.04],[145.187,.04],[145.55,.65],[149,.45],[173,.6],[177.3,.4],[177.552,1],[185,.6],[188,0]],'dialogue':[[0,1],[66,1],[67,.38],[81,.38],[82,1],[134,1],[135,.32],[142,.32],[144,.2],[145.187,1],[149,.3],[172,.3],[174,.6],[177.552,1],[184,.35],[188,0]]})
for name,data in [('programs',PROGRAMS),('session',session)]: (ROOT/'source'/f'{name}.json').write_text(json.dumps(data,indent=2))
print(f'{len(events)} visual events, {len(cues)} designed layers, {len(PROGRAMS)} synthesis families')
