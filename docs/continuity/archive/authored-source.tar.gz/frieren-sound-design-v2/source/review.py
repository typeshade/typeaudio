"""Create paired, linear loudness-matched listening extracts; no automatic creative approval."""
import json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1];OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
OLD=ROOT.parent/'frieren-sound-design/redesign-mix.wav';NEW=ROOT/'redesign-v2.wav'
receipt=[]
for label,start,end in [('red-rupture',20,30),('unseen-force',142,150),('final-discharge',174,184)]:
 measured={}
 for name,path in [('previous',OLD),('revised',NEW)]:
  r=subprocess.run(['ffmpeg','-hide_banner','-ss',str(start),'-t',str(end-start),'-i',str(path),'-af','loudnorm=I=-22:TP=-2:LRA=50:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
  measured[name]=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0]
 target=min(-22,*[float(m['input_i'])-2-float(m['input_tp']) for m in measured.values()])
 for name,path in [('previous',OLD),('revised',NEW)]:
  gain=target-float(measured[name]['input_i']);file=f'{label}-{name}.m4a'
  subprocess.run(['ffmpeg','-v','error','-y','-ss',str(start),'-t',str(end-start),'-i',str(path),'-af',f'volume={gain}dB','-c:a','aac','-b:a','192k','-movflags','+faststart',str(OUT/file)],check=True)
  receipt.append(dict(event=label,version=name,file=file,referenceStart=start,referenceEnd=end,inputLufs=float(measured[name]['input_i']),linearGainDb=gain,pairTargetLufs=target,status='Awaiting listening review'))
(OUT/'comparisons.json').write_text(json.dumps(receipt,indent=2));print('6 aligned review extracts, paired linear loudness matching')
