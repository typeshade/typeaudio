"use typeshade";
export function graphBlock(__out: array<f32>, __state: array<f32>, __clock: array<u32>, __p: array<f32>, __frames: u32): void {
const sampleRate: f32 = 48000; const p0: f32 = __p[0]; const p1: f32 = __p[1]; const p2: f32 = __p[2]; const p3: f32 = __p[3];
let __age: u32 = __clock[0]; for (let __i: u32 = 0; __i < __frames; __i++) { const time: f32 = f32(__age) / sampleRate;
let __v0: f32 = 0;
{ let __r0: u32 = __clock[1]; if (__r0 == 0) { __r0 = u32(__p[4]); } __r0 = __r0 ^ (__r0 << 13); __r0 = __r0 ^ (__r0 >> 17); __r0 = __r0 ^ (__r0 << 5); __clock[1] = __r0; __v0 = f32(__r0) / 2147483648 - 1; }
let __v1: f32 = 0;
{ const input: f32 = __v0; let out: f32 = 0; let state0: f32 = __state[4]; let state1: f32 = __state[5]; let state2: f32 = __state[6]; let state3: f32 = __state[7];
const x: f32 = clamp(time / p2, 0, 1);
state0 += (0.025 + sin(x * 3.14159265) * 0.24) * (input - state0);
state1 += 0.012 * (input - state1);
state2 = fract(state2 + (p0 * (1.6 - x) + 60) / sampleRate);
out = ((state0 - state1) * 1.7 + sin(state2 * 6.2831853) * 0.08) * sin(x * 3.14159265) * sin(x * 3.14159265);
__v1 = out; __state[4] = state0; __state[5] = state1; __state[6] = state2; __state[7] = state3; }
let __v2: f32 = 0;
__v2 = __v1;
__out[__i] = __v2; __age++; } __clock[0] = __age; }