# Frieren sound study, revision 2

This is a review render and its production data, not a final listening-approved mix.
The public template reference is https://www.youtube.com/watch?v=YHCqcyX9N3s.
There is no video in this package. The supplied local reference was used for visual analysis.
The YouTube offset has not been verified in live playback.

The designed range is 0–188 seconds. The later uploader end card is excluded.
51 visible events produce 179 layers from 14 deterministic TypeShade sound families.
TypeAudio GraphDsp renders the dry signals. The Python host applies moving stereo pan,
causal room reflections and narrative gain automation. This is stereo, not binaural or Atmos.
Dialogue and music have not been recreated. For the replacement study, mute YouTube's original
track. A comparison with original sound includes its existing effects as well as dialogue/music.

Files:
- `redesign-v2.m4a`: full-dynamics review mix.
- `redesign-v2-mobile.m4a`: louder mobile review candidate, not yet listening approved.
- `redesign-v2.wav`: 48 kHz/24-bit stereo master (local, excluded from the compact ZIP).
- `stems/`: 11 aligned 24-bit stereo stems (local, excluded from the compact ZIP).
- `review/`: three aligned previous/revised pairs, with linear loudness-matching receipts.
- `workflow.json`: brief, stage statuses, revision notes and the empty listening-review ledger.
- `source/session.json`: spotted events, timing confidence, layers and synthesis graphs.
- `source/programs.json`: authored TypeShade code bodies.
- `template-manifest.json`: draft integration contract using a YouTube reference only.
- `PRODUCTION-WORKFLOW.md`: production stages, agent evidence contract and spatial-audio plan.

Validation: all dry kernels compiled and rendered, no reported invalid/clipped dry samples;
full mix finite and unclipped. Four key events received source-frame inspection. Most other
onsets retain 0.25-second or 2-second visual uncertainty, recorded individually in the session.
The decoded mobile AAC measures about -18.3 LUFS integrated, -1.5 dBTP and 19.8 LU range.
The LRA remains above the normalization request of 11 LU; the quiet narrative sections are
not claimed to meet that target. Phone-speaker clarity, timbral quality, fatigue and spatial
perception still require listening. Numerical checks do not approve creative quality.

Reproduce from this directory with Python, NumPy, SciPy, FFmpeg and Bun installed:

    python source/design.py
    bun source/render.ts
    python source/mix.py
    python source/mobile.py
    python source/review.py
    python source/package.py

`render.ts` currently references the local TypeAudio checkout at `/workspace/typeaudio-feedback`.
Update that import path for another machine. `review.py` requires the earlier review WAV in the
sibling `frieren-sound-design` directory. `package.py` reads the workflow document from the web
repository. Render receipts record the actual engine revision and compiler pin.

No web implementation, R2 upload or deployment is performed by these scripts. The existing
TypeAudio editor's chapter, asset-storage, cached-render invalidation and host-mix parity work
remains necessary before this data becomes a fully editable public template.
